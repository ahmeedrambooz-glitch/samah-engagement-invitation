# Ahmed & Samah — Engagement Invitation

A mobile-friendly static engagement invitation with:
- Click-to-open envelope
- Countdown to 12 November 2026 at 6:00 PM (Egypt time)
- Gallery with sample photos
- Google Maps search link for Solo Yacht
- Save-the-date `.ics` file
- Music toggle (add your own licensed MP3)

## Before sharing
1. Replace the sample gallery photos in `index.html` with your own photo URLs or local images.
2. Add a licensed music track named `music.mp3` inside the `assets` folder.
3. Verify the exact Solo Yacht venue location and update the Google Maps URL if needed.
4. Check the event time and date.

## Deploy to Vercel (no build step required)
1. Create a GitHub account and sign in.
2. Create a new repository, for example `ahmed-samah-engagement`.
3. Upload `index.html`, `vercel.json`, `README.md`, and the `assets` folder.
4. Open https://vercel.com/new and import that GitHub repository.
5. Keep the default settings and click **Deploy**.
6. Vercel will provide a live `*.vercel.app` URL. Copy that URL and share it on WhatsApp.
7. To change the site later, update the files in GitHub; Vercel redeploys automatically.

Official guide: https://vercel.com/docs/deployments/overview

## Notes
- This is an original design inspired by the invitation concept, not a copy of another site's source code.
- The music feature will show a prompt until you add `assets/music.mp3`.
- The sample photos are hosted by Unsplash; replace them with photos you have permission to use.
- The map button opens a Google Maps search for “Solo Yacht Egypt”; confirm the exact pin before sending invitations.
